

#include "stdafx.h"
#include "Form.h"


using namespace main1;

[STAThreadAttribute]





int main(array<System::String ^> ^args)
{
	// Create the main window and run it

	Application::Run(gcnew Form());

	return 0;
}
